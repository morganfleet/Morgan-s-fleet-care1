UPLOAD INSTRUCTIONS

1. Open your Morgans Fleet Care GitHub repository.
2. Upload taviso.html into the main website folder.
3. Upload taviso-logo.jpg into the same folder as taviso.html.
4. Your QR code should point to:

https://morganfleet.github.io/morgansfleetcare/taviso.html

Important:
This page uses a mailto enquiry form, which opens the visitor's email app with the enquiry ready to send.
